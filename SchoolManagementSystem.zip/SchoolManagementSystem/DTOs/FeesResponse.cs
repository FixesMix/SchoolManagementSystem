﻿namespace SchoolManagementSystem.DTOs
{
    public class FeesResponse
    {
        //what you give back to the user
        public decimal FeeAmount { get; set; }
        public int StudentLevel { get; set; }
    }
}
