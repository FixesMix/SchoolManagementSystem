﻿namespace SchoolManagementSystem.DTOs
{
    public class CourseFeeResponse
    {
        public decimal FeeAmount { get; set; }
        public string CourseId { get; set; }
    }
}
