﻿namespace SchoolManagementSystem.DTOs.Grades
{
    public class GetGradeRequest
    {
        public string StudentId { get; set; }
        public string CourseId { get; set; }
    }
}
