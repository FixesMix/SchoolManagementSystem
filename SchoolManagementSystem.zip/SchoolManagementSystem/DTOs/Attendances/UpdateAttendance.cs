﻿namespace SchoolManagementSystem.DTOs.Attendances
{
    public class UpdateAttendance
    {
        public bool IsPresent { get; set; }
    }
}
