﻿using System.Security;

namespace SchoolManagementSystem.Models
{
    public class Classroom
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Capacity { get; set; }
        public string Location  { get; set; }
    }
}
